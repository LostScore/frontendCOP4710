function Profile() {
    return(
        <div className = "Profile">
            <p> Profile Page</p>
        </div>

    );
}

export default Profile;