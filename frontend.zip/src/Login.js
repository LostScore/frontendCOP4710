function Login() {
  return (
    <div className="Login">
      <header className="Login-header">
        <form>
              <formgroup>
                <formlabel>Login</formlabel>
                <input type="Username" class = "form-control" id="exampleUserName" aria-describedby="UserHelp" placeholder="Username"></input>
                <small id="userHelp" class="form-text text-muted">Enter Username</small>
              </formgroup>
              <formgroup>
                <formlabel>Password</formlabel>
                <input type="Password" class = "form-control" id="exampleUserName" aria-describedby="PassHelp" placeholder="Password"></input>
              </formgroup>
          <button variant="secondary" type="submit">Sign In</button>
        </form>
      </header>
    </div>
  );
}

export default Login;
