function Events() {
    return(
        <div className = "Event">
            <p> Events</p>
        </div>

    );
}

export default Events;