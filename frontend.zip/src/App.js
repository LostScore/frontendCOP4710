import './App.css';
import NavBar from './NavBar.js';
import Login from './Login.js';
import Profile from './Profile.js';
import Events from './Event'; 
import { BrowserRouter as Router, Route} from 'react-router-dom';

function App() {
  return (
    <Router>
      <NavBar />
      
      <div className="App">
        <Route path="/login" component={Login} />
        <Route path="/prof" component={Profile} />
        <Route path="/events" component={Events} />
        
        <p>
            Edit <code>src/App.js</code> and save to reload.

          </p>
          <a
            className="App-link"
            href="https://reactjs.org"
            target="_blank"
            rel="noopener noreferrer"
          >
            Learn React
          </a>
      </div>
    </Router>
  );
}

export default App;
