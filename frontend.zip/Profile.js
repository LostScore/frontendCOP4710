
function Profile() {
  return (
    <div className="Profile">
      <header className="Profile-header">
        <p>Profile</p>
      </header>
    </div>
  );
}

export default Profile;
